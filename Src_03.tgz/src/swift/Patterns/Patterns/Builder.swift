//
//  Builder.swift
//  Patterns
//
//  Created by Jon Lindberg on 1/3/19.
//  Copyright © 2019 Jon Lindberg. All rights reserved.
//

import Foundation

public class Builder
{
	init(factory : Document)
	{
		self.factory	= factory
	}
	
	internal var factory		: Document
	internal var elementStack	= [Element]()
	internal var currentElement	: Element?	= nil
	internal var currentAttribute	: Attr?		= nil
	
	public var document	: Document	{ get { return factory } }
	
	public func addValue(text : String) throws
	{
		_ = try elementStack[elementStack.count - 1].appendChild(newChild: document.createTextNode(data: text.trimmingCharacters(in: .whitespacesAndNewlines)))
	}
	public func confirmElement(tag : String)
	{
		// Throw an exception if tag.trimmingCharacters != currentElement.getTagName()
	}
	public func createAttribute(attribute : String)
	{
		let trimmed = attribute.trimmingCharacters(in: .whitespacesAndNewlines)
		
		var	counter		= 0
		var	endIndex	= attribute.endIndex
		
		for index in attribute.indices
		{
			if (trimmed.count - 1) == counter
			{
				endIndex	= index
			}
			
			counter	+= 1
		}
		
		currentAttribute	= document.createAttribute(name: String(trimmed[..<endIndex]))
	}
	public func createElement(tag : String) throws
	{
		currentElement	= document.createElement(tagName: tag.trimmingCharacters(in: .whitespacesAndNewlines))
		
		if elementStack.count == 0
		{
			_ = try factory.appendChild(newChild: currentElement!)
		}
		else
		{
			_ = try elementStack[elementStack.count - 1].appendChild(newChild: currentElement!)
		}
	}
	public func createProlog()
	{
		// null method in this implementation
	}
	public func endProlog()
	{
		// null method in this implementation
	}
	public func identifyProlog(id : String)
	{
		// null method in this implementation
	}
	public func popElement() -> Bool
	{
		currentElement	= elementStack.remove(at: elementStack.count - 1)
		return elementStack.count > 0
	}
	public func pushElement()
	{
		elementStack.append(currentElement!)
		currentElement	= nil
	}
	public func valueAttribute(value : String) throws
	{
		let trimmed	= value.trimmingCharacters(in: .whitespacesAndNewlines)
		
		var	counter		= 0
		var	startIndex	= value.startIndex
		var	endIndex	= value.endIndex

		for index in value.indices
		{
			if (trimmed.count - 1) == counter
			{
				endIndex	= index
			}
			else if 1 == counter
			{
				startIndex	= index
			}
			
			counter	+= 1
		}
		
		currentAttribute!.value	= String(trimmed[startIndex..<endIndex])
		
		if let ce = currentElement
		{
			_ = try ce.setAttributeNode(newAttr: currentAttribute!)
		}
	}
}
