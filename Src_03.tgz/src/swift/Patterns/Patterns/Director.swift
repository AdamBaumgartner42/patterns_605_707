//
//  Director.swift
//  Patterns
//
//  Created by Jon Lindberg on 1/3/19.
//  Copyright © 2019 Jon Lindberg. All rights reserved.
//

import Foundation

public class Director
{
	enum State
	{
		case BEFORE_PROLOG, AFTER_PROLOG, PARSING_ELEMENT, IN_NONNULL_ELEMENT, END
	}
	
	init(filename : String, builder : Builder) throws
	{
		let tokenizer				= XMLTokenizer(filename: filename)!
		var documentLocation			= State.BEFORE_PROLOG
		var lastToken				= XMLTokenizer.TokenTypes.NULL_TOKEN
		var token : XMLTokenizer.XMLToken	= tokenizer.getNextToken()
		var currentToken			= token.type

		while currentToken != XMLTokenizer.TokenTypes.NULL_TOKEN
		{
			switch documentLocation
			{
			case .BEFORE_PROLOG:
				switch lastToken
				{
				case .NULL_TOKEN, .VALUE:
					switch currentToken
					{
					case .PROLOG_START:
						builder.createProlog()
						documentLocation	= .AFTER_PROLOG
					default:
						break
					}
				default:
					break
				}
			case .AFTER_PROLOG:
				switch lastToken
				{
				case .PROLOG_START:
					switch currentToken
					{
					case .PROLOG_IDENTIFIER:
						builder.identifyProlog(id: token.token)
					default:
						break
					}
				case .PROLOG_IDENTIFIER:
					switch currentToken
					{
					case .ATTRIBUTE:
						builder.createAttribute(attribute: token.token)
					case .PROLOG_END:
						builder.endProlog()
						documentLocation	= .PARSING_ELEMENT
					default:
						break
					}
				case .ATTRIBUTE:
					switch currentToken
					{
					case .ATTRIBUTE_VALUE:
						try builder.valueAttribute(value: token.token)
					default:
						break
					}
				case .ATTRIBUTE_VALUE:
					switch currentToken
					{
					case .ATTRIBUTE:
						builder.createAttribute(attribute: token.token)
					case .PROLOG_END:
						builder.endProlog()
						documentLocation	= .PARSING_ELEMENT
					default:
						break
					}
				default:
					break
				}
			case .PARSING_ELEMENT:
				switch lastToken
				{
				case .TAG_START:
					switch currentToken
					{
					case .ELEMENT:
						try builder.createElement(tag: token.token)
					default:
						break
					}
				case .ELEMENT:
					switch currentToken
					{
					case .ATTRIBUTE:
						builder.createAttribute(attribute: token.token)
					case .TAG_END:
						documentLocation	= .IN_NONNULL_ELEMENT
						builder.pushElement()
					case .NULL_TAG_END:
						break
					default:
						break
					}
				case .ATTRIBUTE:
					switch currentToken
					{
					case .ATTRIBUTE_VALUE:
						try builder.valueAttribute(value: token.token)
					default:
						break
					}
				case .ATTRIBUTE_VALUE:
					switch currentToken
					{
					case .ATTRIBUTE:
						builder.createAttribute(attribute: token.token)
					case .TAG_END:
						documentLocation	= .IN_NONNULL_ELEMENT
						builder.pushElement()
					case .NULL_TAG_END:
						break
					default:
						break
					}
				case .PROLOG_END:
					switch currentToken
					{
					case .TAG_START:
						// Actually create element when we read tag name.
						break
					default:
						break
					}
				case .NULL_TAG_END:
					switch currentToken
					{
					case .TAG_START:
						// Actually create element when we read tag name.
						break
					case .TAG_CLOSE_START:
						documentLocation	= .IN_NONNULL_ELEMENT
					default:
						break
					}
				default:
					break
				}
			case .IN_NONNULL_ELEMENT:
				switch lastToken
				{
				case .ELEMENT:
					switch currentToken
					{
					case .TAG_END:
						if !builder.popElement()
						{
							documentLocation	= .END
						}
					default:
						break
					}
				case .TAG_END:
					switch currentToken
					{
					case .TAG_START:
						documentLocation	= .PARSING_ELEMENT
						// Actually create element when we read tag name.
					case .VALUE:
						try builder.addValue(text: token.token)
					case .TAG_CLOSE_START:
						break
					default:
						break
					}
				case .VALUE:
					switch currentToken
					{
					case .TAG_START:
						documentLocation	= .PARSING_ELEMENT
					case .TAG_CLOSE_START:
						break
					default:
						break
					}
				case .TAG_CLOSE_START:
					switch currentToken
					{
					case .ELEMENT:
						builder.confirmElement(tag: token.token)
					default:
						break
					}
				default:
					break
				}
			case .END:
				switch currentToken
				{
				case .NULL_TOKEN:
					break
				default:
					break
				}
			}
			
			lastToken	= currentToken
			token		= tokenizer.getNextToken()
			currentToken	= token.type
		}
	}
}
